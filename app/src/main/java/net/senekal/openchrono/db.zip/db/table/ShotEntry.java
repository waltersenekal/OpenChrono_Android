package net.senekal.openchrono.db.table;

import androidx.room.Entity;
import androidx.room.ForeignKey;
import androidx.room.Index;
import androidx.room.PrimaryKey;

@Entity(
        tableName = "shot_entry",
        foreignKeys = @ForeignKey(
                entity = Device.class,
                parentColumns = "id",
                childColumns = "deviceId",
                onDelete = ForeignKey.CASCADE
        ),
        indices = {@Index(value = "deviceId")} // Add an index for the deviceId column
)
public class ShotEntry {
    @PrimaryKey(autoGenerate = true)
    public int id;

    public int deviceId; // Foreign key referencing Device.id

    public String usageDetails;

    public ShotEntry(int deviceId, String usageDetails) {
        this.deviceId = deviceId;
        this.usageDetails = usageDetails;
    }
}