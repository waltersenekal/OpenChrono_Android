package net.senekal.openchrono.db.table;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.Query;

import java.util.List;

@Dao
public interface IShotEntryDao {
    @Insert
    void insert(ShotEntry shotEntry);

    @Query("SELECT * FROM shot_entry WHERE deviceId = :deviceId")
    List<ShotEntry> getUsageByDeviceId(int deviceId);
}