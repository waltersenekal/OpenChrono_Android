package net.senekal.openchrono.db;

import android.content.Context;

import net.senekal.openchrono.db.AppDatabase;
import net.sqlcipher.database.SQLiteDatabase;
import net.sqlcipher.database.SupportFactory;
import androidx.room.Room;

public class DatabaseClient {
    private static AppDatabase appDatabase;

    public static AppDatabase getInstance(Context context) {
        if (appDatabase == null) {
            // Generate a passphrase for encryption
            byte[] passphrase = SQLiteDatabase.getBytes("your-secure-passphrase".toCharArray());
            SupportFactory factory = new SupportFactory(passphrase);

            // Build the encrypted Room database
            appDatabase = Room.databaseBuilder(context, AppDatabase.class, "encrypted_database")
                    .openHelperFactory(factory)
                    .build();
        }
        return appDatabase;
    }
}